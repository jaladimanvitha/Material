<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Assignment</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<style>
#logo {
top : 20%
width:200px;
height:70px;
}

</style>
<?php
	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn)
{
    die("Connection failed: " . mysqli_connect_error());
}else {
	$sql1 = 'select * from control';
	$result = mysqli_query($conn,$sql1);
	$headfoo = mysqli_fetch_row($result);
}
?>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
    <h1><span><a href="#"><?php echo $headfoo[0]; ?></a></span> </h1> 
    </div>
    <nav>
      <ul>
        <li><a href="login.php">Login</a></li>
        <li class="last"><a href="register.php">Sign Up</a></li>
      </ul>
    </nav>
  </header>
</div>

<div class="wrapper row2">

  <div id="container" class="clear">
  <h1><a style="font-size:23px">Project</a></h1>
    <div id="homepage">
         
    </div>
    <br/>
	<br/>
    <div id="content">
      <section id="posts" class="last clear">
        <ul>
          <li>
            <article class="clear">                
                  <h2>What is PHP?</h2>
                  <p>* &nbsp; PHP is a server scripting language, and a powerful tool for making dynamic and interactive Web pages.<br>
                     * &nbsp; PHP is a widely-used, free, and efficient alternative to competitors such as Microsoft's ASP.<br>
					 * &nbsp; PHP is an acronym for "PHP: Hypertext Preprocessor"<br></p>
                  <footer class="more"><a href="#">Read More &raquo;</a></footer>              
            </article>
          </li>
          <li class="last">
            <article class="clear">            
                  <h2>PHP is an amazing and popular language!</h2>
                  <p>It is powerful enough to be at the core of the biggest blogging system on the web (WordPress)!
                     It is deep enough to run the largest social network (Facebook)!
                     It is also easy enough to be a beginner's first server side language!</p>
                  <footer class="more"><a href="#">Read More &raquo;</a></footer>                
            </article>
          </li>
        </ul>
      </section>
    </div>
    <aside id="right_column">
      <h2 class="title">Categories</h2>
      <nav>
        <ul>
          <li><a href="#">HTML</a></li>
          <li><a href="#">Java Script</a></li>
          <li><a href="#">JQuery</a></li>
          <li><a href="#">PHP and MySql</a></li>
          <li class="last"><a href="#">Magento</a></li>
        </ul>
      </nav>
    </aside>
  </div>
</div>
<!-- Footer -->
<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left"><?php echo $headfoo[1]; ?></p>
    <p class="fl_right"><a href="#">Tech Mahindra</a></p>
  </footer>
</div>
</body>
</html>
