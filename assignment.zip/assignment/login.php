<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Assignment</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<style>
input[type=text],input[type=password]{
    width: 40%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid grey;
    border-radius: 4px;
    box-sizing: border-box;
}
input:hover{border: 1px solid black;}
input[type=submit],input[type=reset] {
background-color:grey;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius : 5px;	
}
input[type=submit]:hover,input[type=reset]:hover {
background-color:#424851;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;    
}
.login {

border-radius : 20px;
padding-left : 60px;
margin-right : 50px;
padding-top : 5%;
padding-bottom : 11%;

}
#logo {
top : 20%
width:200px;
height:80px;
}
#log :hover {
	text-decoration: underline;
}
</style>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment";
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn)
{
    die("Connection failed: " . mysqli_connect_error());
}
$sql1 = 'select * from control';
	$result = mysqli_query($conn,$sql1);
	$headfoo = mysqli_fetch_row($result);
if(isset($_POST['uname'])){
$login=$_POST['uname'];
$passwd=$_POST['pass'];

if($login!=''&&$passwd!='')
{
    $query='select * from customer where user_name="'.$login.'" and password="'.$passwd.'"' or die("Connection failed: " . mysqli_connect_error());
    $search = mysqli_query($conn,$query);
	$match  = mysqli_num_rows($search);
    if($match > 0){
		session_start();  
    $_SESSION['user']=$login;
        header("Location: edit.php"); 	
    }else{
		$message = 'Invalid Username or Password';
        
		
    }	
}
}

?>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
     <h1><span><a href="#"><?php echo $headfoo[0]; ?></a></span> </h1>
    </div>
    <nav>
      <ul>
	    <li><a href="index.html">Home</a></li>
		<li><a id="log" style="text-decoration:underline;" href="adminlogin.php">Login as Admin</a></li>
        <li class="last"><a href="register.php">Sign Up</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
  <div id="container" class="clear">
  <h1><a style="font-size:23px">Login</a></h1>
    <div class="login">
	
	<form id="login-form" action="" method="POST">
	<p><b>User Name</b></br>
				<input type="text" name="uname" placeholder="Enter your User name" required/></p>

			<p><b>Password</b></br>
				<input type="password" name="pass" placeholder="Enter your password" required/></p>
				<p><input id="rememberme" name="rememberme" value="remember" type="checkbox" /> &nbsp;Remember me </p>
				<p><input type="submit" name="submit" value="Login" /><span><input type="reset" value="Cancel"/></p></span>
	</form>
	
	<p style="color:red"> <?php 
      if(isset($message)){
        echo $message;
      }
    ?></p>
	</div>
  </div>
</div>

<div class="wrapper row3">
  <footer id="footer" class="clear">
   <p class="fl_left"><?php echo $headfoo[1]; ?></p>
    <p class="fl_right"><a href="#">Tech Mahindra</a></p>
  </footer>
</div>
</body>
</html>