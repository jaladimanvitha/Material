<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
<title>Assignment</title>
<meta charset="UTF-8">
<link rel="stylesheet" href="styles/layout.css" type="text/css">
<style>
textarea,input[type=text],select,input[type=password]{
    width: 30%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid grey;
    border-radius: 4px;
    box-sizing: border-box;
}
option { 
   padding-bottom:2px;
}
select:hover,input:hover{border: 1px solid black;}
input[type=submit],input[type=reset] {
background-color:grey;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
border-radius : 5px;	
}
input[type=submit]:hover,input[type=reset]:hover {
background-color:#424851;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;    
}
input[type=checkbox] {
border:2px dotted #00f;

background:#ff0000;
}
input[type=radio] {

    position: relative;
    padding-left: 35px;
    margin-bottom: 12px;
    cursor: pointer;
    font-size: 22px;
}
#logo {
top : 20%
width:200px;
height:70px;
}
</style>
<?php 
$captcha=$uname=$pass=$pass1=$email=$phone=$gender=$location=$length=$message="";
session_start();
if(isset($_POST['captcha'])){
$captcha=$_POST['captcha'];	
}
if ($captcha != $_SESSION['digit'] OR $_SESSION['digit']=='')  { 
     $error="Incorrect CAPTCHA."; 
} else if(isset($_POST['submit'])) {
$uname= $_POST['uname'];
$pass=$_POST['pass'];
$pass1=$_POST['pass1'];
$email= $_POST['email'];
$phone= $_POST['contact'];
$gender = $_POST['gender'];
$location = $_POST['location'];
$length= strlen($phone);
if($length != 10) {
	$message="Mobile Number is not appropriate";
} else if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
	$message="Invalid Email-Id";
} else if($pass!=$pass){
	$message="Password Mismatch";
} else {
	$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql= 'INSERT INTO customer(user_name, password, email, phone, gender, location) VALUES ("'.$uname.'","'.$pass.'","'.$email.'",'.$phone.',"'.$gender.'","'.$location.'")';
if (mysqli_query($conn, $sql)) {
	$message="Record Inserted successfully";
} else {
	$message="Error Inserting record: " . mysqli_error($conn);
}
}
}
?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "assignment";
$conn = mysqli_connect($servername, $username, $password, $dbname);
$sql1 = 'select * from control';
	$result = mysqli_query($conn,$sql1);
	$headfoo = mysqli_fetch_row($result);
?>
</head>
<body>

<div class="wrapper row1">
  <header id="header" class="clear">
    <div id="hgroup">
    <h1><span><a href="#"><?php echo $headfoo[0]; ?></a></span> </h1>
    </div>
    <nav>
      <ul>
	    <li><a href="index.html">Home</a></li>
        <li class="last"><a href="login.php">Login</a></li>
      </ul>
    </nav>
  </header>
</div>
<div class="wrapper row2">
 <div id="container" class="clear">
  <u><h1><a href="register.php" style="font-size:23px">Customer Registration Form</a></h1></u>
    <div id="homepage">
        <form method="POST" action="">
			<p><b>User Name</b></br>
				<input type="text" name="uname" placeholder="Please Enter your user name" required/></p>

			<p><b>Password</b></br>
				<input type="password" name="pass" placeholder="Please choose a password" required/></p>
<p><b>Confirm Password</b></br>
				<input type="password" name="pass1" placeholder="Please confirm the password" required/></p>
<p><b>Email-Id</b></br>
<input type="text" name="email" placeholder="example@gmail.com" required/><p>

<p><b>Contact</b></br>
<input type="text" name="contact" placeholder="Mobile No." required/></p>
<p><b>Gender</b></br>
<input type="radio" name="gender" value="Male"/> &nbsp Male <br>
<input type="radio" name="gender" value="Female"/> &nbsp Female <br>
<input type="radio" name="gender" value="Other"/> &nbsp Other</p>
<p><b>Location</b></br>
<select name="location" required>
 <option value="">Select</option>
 <option value="Bangalore">Bangalore</option>
 <option value="Chennai">Chennai</option>
 <option value="Delhi">Delhi</option>
 <option value="Hyderabad">Hyderabad</option>
 <option value="Pune">Pune</option>
 <option value="Mumbai">Mumbai</option>
</select></p>
<p><b>CAPTCHA</b></br>
<img src="captcha.php" width="150" height="60" border="3" alt="CAPTCHA"></p>
<p><input type="text" size="6" maxlength="5" name="captcha" placeholder="Please Enter the CAPTCHA" value=""><br>
<small><i>copy the digits from the image into this box</i></small></p>
<p><input type="submit" name="submit" id="sub" value="Register"/><span><input type="reset" name="reset" id="res" value="Cancel"/></p></span>
</form>
<br>
<p style="color:red"> <?php 
      if(isset($message)){
        echo $message;
      }
    ?></p>
    </div> 
   </div>
</div>

<div class="wrapper row3">
  <footer id="footer" class="clear">
    <p class="fl_left"><?php echo $headfoo[1]; ?></p>
    <p class="fl_right"><a href="#">Tech Mahindra</a></p>
  </footer>
</div>
</body>
</html>
